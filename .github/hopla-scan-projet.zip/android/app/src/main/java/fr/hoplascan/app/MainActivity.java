package fr.hoplascan.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
