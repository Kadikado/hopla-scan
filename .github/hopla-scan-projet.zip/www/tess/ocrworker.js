/* Hopla Scan : charge le moteur OCR ; le fichier de langue est hébergé encodé en base64 (texte) */
(function () {
  var f = self.fetch.bind(self);
  self.fetch = function (u, o) {
    if (typeof u === "string" && /\/fra\.traineddata\.gz$/.test(u)) {
      return f(u.replace(/fra\.traineddata\.gz$/, "fra-traineddata-gz.txt"), o).then(function (r) {
        if (!r.ok) return r;
        return r.text().then(function (t) {
          var s = atob(t.trim()), b = new Uint8Array(s.length);
          for (var i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
          return new Response(b, { status: 200 });
        });
      });
    }
    return f(u, o);
  };
})();
importScripts("worker.min.js");
